<?php

return [
    'user' => 'hadawate.ingineru.panthiya@gmail.com',
    'pass' => 'Navod@97'
];

?>